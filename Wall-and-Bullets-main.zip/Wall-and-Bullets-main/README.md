Output link: https://labdhibora.github.io/Wall-and-Bullets/.
